﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBankOOAD.Classes
{
    class AcceptorDonorInfo:BloodBase
    {
        public AcceptorDonorInfo():base()
        {

        }

        public override int Donors()
        {
            return base.Donors();
        }

        public override int Acceptor()
        {
            return base.Acceptor();
        }
    }
}
